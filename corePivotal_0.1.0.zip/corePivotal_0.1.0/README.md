<!-- README.md -->

# Core Pivotal Authorship

This extension computes core-pivotal authorship metrics. 

The source is based on a modification to gscholarlens (https://arxiv.org/abs/2509.04124) which is distributed under MIT and/or MPL 2.0. 


## 📄 License

This project is released under the **MIT License**

---

## Disclaimer

Core Pivotal Authoship should not be used by anyone. 