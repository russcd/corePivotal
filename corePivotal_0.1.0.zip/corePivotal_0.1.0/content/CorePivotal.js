const fontPath=chrome.runtime.getURL("fonts/SchibstedGrotesk.ttf"),schibsted_grotesk=new FontFace("schibsted-grotesk",`url(${fontPath})`);let excelData=!1,retractionWatchDB=!1,profileScraped=!1,isDesktop=!1,isPermitted=!1,isInitialized=!1,tsvContent="Index	Title	Authors	Total_Authors	Year	Citations	Journal	Q*	ImpactFactor_5years	Publication_Considered	Core_Pivotal_Author\n";async function loadScript(t,e,o){var i=document.head,r=document.createElement("script");return r.type="text/javascript",r.src=t,r.id=o,r.onreadystatechange=e,r.onload=e,i.appendChild(r),!0}async function openPopupWindow(t){let e={url:t,type:"popup",width:400,height:600,left:100,top:100,focused:!0};return"undefined"!=typeof browser&&browser.windows?await browser.windows.create(e):"undefined"!=typeof chrome&&chrome.windows?chrome.windows.create(e):console.error("No windows API available"),!0}async function releaseSemaphoreAndReload(){chrome.runtime.sendMessage({type:"release_semaphore"},t=>(t&&console.log(t?.status),window.location.reload(),!0))}async function releaseSemaphore(){chrome.runtime.sendMessage({type:"release_semaphore"},t=>(t&&console.log(t?.status),!0))}function checkInitialization(){chrome.runtime.sendMessage({type:"initialization_check"},t=>{isInitialized=t.isInitialized})}function checkPermissions(){chrome.runtime.sendMessage({type:"permissions_check"},t=>{if(!(isPermitted=t.isPermitted)){window.confirm("Core Pivotal requires your permissions. Please click the extension icon to allow a permission request.")&&window.location.reload();return}})}function checkDevice(){chrome.runtime.sendMessage({type:"device_check"},t=>{isDesktop=t.isDesktop})}function enableButton(){let t=document.getElementById("inject-content-button");t.textContent="Run Core Pivotal",t.disabled=!1,t.textContent.color="white",t.style.width="fit-content",t.style.display="flex",t.style.alignItems="center",t.style.gap="5px",t.style.fontSize="16px",t.style.color="white",t.style.marginTop="20px",t.style.marginBottom="10px",t.style.zIndex="1000",t.style.borderRadius="7px",t.style.cursor="pointer",t.style.boxShadow="3px 3px 5px rgba(0,0,0,0.6)",t.style.fontFamily="schibsted-grotesk, sans-serif",t.style.backgroundColor="rgba(0,0,0,0.8)";let e=document.createElement("img");e.src=chrome.runtime.getURL("icons/icon128.png"),e.alt="Core Pivotal",e.style.height="20px",e.style.width="20px",e.style.objectFit="contain",t.prepend(e)}schibsted_grotesk.load().then(t=>{document.fonts.add(t),document.body.style.fontFamily="schibsted-grotesk, sans-serif"}).catch(t=>{console.error("Font failed to load:",t)}),window.location.href.includes("user=")&&window.location.href.includes("scholar.google")&&(checkPermissions(),checkDevice(),createButton(),chrome.runtime.sendMessage({type:"wait_for_initialization"},t=>{console.log(t.status),async function(){let t=window.location.href.toString(),e=await fetchWithSessionCache(t,t,refetch=!0);e&&200==e.status||releaseSemaphoreAndReload(),excelData=await getJCRExcel(),retractionWatchDB=await getRetractionWatchDB(),enableButton()}()})),window.addEventListener("beforeunload",async()=>{await releaseSemaphore()},!0);const cyrb53=(t,e=0)=>{let o=3735928559^e,i=1103547991^e;for(let r=0,n;r<t.length;r++)o=Math.imul(o^(n=t.charCodeAt(r)),2654435761),i=Math.imul(i^n,1597334677);return o=Math.imul(o^o>>>16,2246822507),o^=Math.imul(i^i>>>13,3266489909),i=Math.imul(i^i>>>16,2246822507),4294967296*(2097151&(i^=Math.imul(o^o>>>13,3266489909)))+(o>>>0)};async function fetchWithSessionCache(t,e,o=!1){if(!t||0===t.length)return null;let i=cyrb53(t),r=await sessionStorage.getItem(i);if(r&&!o)return r;try{let n=await fetch(e);return n&&200==n.status&&await sessionStorage.setItem(i,n),n}catch(a){return console.error("Error fetching data:",a),null}return!0}function getRandomArbitrary(t,e){return Math.random()*(e-t)+t}function getRandomInt(t,e){return t=Math.ceil(t),Math.floor(Math.random()*((e=Math.floor(e))-t+1))+t}async function createInlineWorker(t){let e=await fetch(t),o=await e.text(),i=new Blob([o],{type:"application/javascript"}),r=URL.createObjectURL(i),n=new Worker(r);return n.addEventListener("online",()=>URL.revokeObjectURL(r)),n.addEventListener("offline",()=>{URL.revokeObjectURL(r),i.dispose()}),n}async function getJCRExcel(){try{return new Promise(t=>{chrome.storage.local.get("jcrJSON",e=>{t(e.jcrJSON||!1)})})}catch(t){console.error("Error: Could not fetch JCR excel data. "+t),await releaseSemaphore()}}async function getRetractionWatchDB(){try{return new Promise(t=>{chrome.storage.local.get("retractionwatchdb",e=>{t(e.retractionwatchdb||!1)})})}catch(t){console.error("Error: Could not RetractionWatchDB blob data. "+t),await releaseSemaphore()}}function createButton(){if(!document.getElementById("gsc_prf_w"))return;let t=document.querySelector("#gsc_prf");if(!t)return;if(document.getElementById("inject-content-button")){let e=document.getElementById("inject-content-button");e.style.display="none";return}let o=document.createElement("button");o.id="inject-content-button",o.textContent="Initializing Core Pivotal...",o.disabled=!0,o.style.width="fit-content",o.style.display="flex",o.style.alignItems="center",o.style.gap="5px",o.style.fontSize="16px",o.style.marginTop="20px",o.style.marginBottom="10px",o.style.zIndex="1000",o.style.borderRadius="7px",o.style.cursor="not-allowed",o.style.boxShadow="3px 3px 5px rgba(0,0,0,0.6)",o.style.fontFamily="schibsted-grotesk, sans-serif";let i=document.createElement("img");i.src=chrome.runtime.getURL("icons/icon128.png"),i.alt="Core Pivotal",i.style.height="20px",i.style.width="20px",i.style.objectFit="contain",o.prepend(i),t.append(o),o.addEventListener("click",()=>{try{startScraping(),o.style.display="none"}catch(t){console.error("Error at startScraping() event: "+t),o.style.display="none",(async()=>{await releaseSemaphore()})()}},{passive:!0})}function rebuildYearwiseData(t){let e=new Map;for(let[o,i]of t){let r=new Map;for(let[n,a]of i){let s;s=Array.isArray(a)&&a.every(([t,e])=>Array.isArray(e)&&e.every(t=>Array.isArray(t)&&2===t.length))?new Map(a.map(([t,e])=>[t,new Map(e)])):Array.isArray(a)&&a.every(t=>Array.isArray(t)&&2===t.length)?new Map(a):a,r.set(n,s)}e.set(o,r)}return e}async function mergeYearwiseData(t,e){for(let[o,i]of e.entries())for(let[r,n]of(t.has(o)||t.set(o,new Map),i.entries())){t.get(o).has(r)||t.get(o).set(r,new Map);let a=t.get(o).get(r),s=n;for(let[l,c]of s.entries())if(a.has(l)){let d=a.get(l);if("number"==typeof d&&"number"==typeof c)a.set(l,d+c);else if(d instanceof Map&&c instanceof Map)for(let[g,u]of c.entries())d.has(g)?d.set(g,d.get(g)+u):d.set(g,u);else Array.isArray(d)&&Array.isArray(c)?a.set(l,[...new Set([...d,...c])]):console.warn(`Incompatible types for key ${l} in year ${o}`)}else a.set(l,c)}}function startScraping(){try{let t=performance.now();document.addEventListener("visibilitychange",async()=>{"visible"===document.visibilityState&&!0===profileScraped&&tN()}),window.addEventListener("focus",async()=>{!0===profileScraped&&tN()}),document.getElementsByTagName("body")[0].style.overflow="hidden";let e=0,o=0,i=Math.max(1,navigator.hardwareConcurrency-1),r=navigator.hardwareConcurrency+1,n=!1,a=!1,s=!1,l=0,c=0,d=0,g=0,u=0,$=0,p=0,h=0,b=0,f=0,y=0,_=0,x=0,m=0,C=0,w=0,v=0,k=0,S=0,A=0,q=["First_Author","Second_Author","Co_Author","Corresponding_Author","Core_Pivotal_Author"],E=[.9,.5,.1,1,1],P=[0,0,0,0,0],j=[0,0,0,0,0],z=[0,0,0,0,0],Q=new Map,I=/^(.*?)(?=\s+\d|,|\s\()/,B=["rgba(75, 192, 192, 0.2)","rgba(153, 102, 255, 0.2)","rgba(255, 159, 64, 0.2)","rgba(54, 162, 235, 0.2)"],R=["rgba(75, 192, 192, 1)","rgba(153, 102, 255, 1)","rgba(255, 159, 64, 1)","rgba(54, 162, 235, 1)"],T=[["rgba(166, 54, 3, 0.4)","rgba(84, 39, 143, 0.4)","rgba(0, 109, 44, 0.4)","rgba(8, 81, 156, 0.4)"],["rgba(230, 85, 13, 0.4)","rgba(117, 107, 177, 0.4)","rgba(49, 163, 84, 0.4)","rgba(49, 130, 189,0.4)"],["rgba(253, 141, 60, 0.4)","rgba(158, 154, 200, 0.4)","rgba(116, 196, 118, 0.4)","rgba(107, 174, 214, 0.4)"],["rgba(253, 190, 133, 0.4)","rgba(203, 201, 226, 0.4)","rgba(186, 228, 179, 0.4)","rgba(189, 215, 231, 0.4)"],["rgba(254, 237, 222, 0.4)","rgba(242, 240, 247, 0.4)","rgba(237, 248, 233, 0.4)","rgba(239, 243, 255, 0.4)"]],L=[["rgb(127, 44, 2)","rgb(58, 27, 107)","rgb(0, 75, 28)","rgb(5, 52, 105)"],["rgb(179, 63, 11)","rgb(89, 79, 137)","rgb(38, 122, 62)","rgb(35, 97, 138)"],["rgb(184, 94, 42)","rgb(108, 106, 148)","rgb(78, 139, 82)","rgb(73, 115, 155)"],["rgb(194, 151, 99)","rgb(157, 156, 186)","rgb(145, 161, 135)","rgb(148, 173, 197)"],["rgb(205, 141, 108)","rgb(180, 168, 207)","rgb(157, 208, 150)","rgb(150, 180, 230)"]],N=chrome.runtime.getURL("libs/chart.umd.js"),D=[],W=[],F=[],M=new Map,J=[],G=["≽^•⩊•^≼","ฅ^•ﻌ•^ฅ","ᓚ₍ ^. ̫ .^₎","ᓚ₍ ^. .^₎","—ฅ/ᐠ. ̫ .ᐟ\\ฅ —","₍^. .^₎⟆","ฅᨐฅ","ㅤ/ᐠ - ˕ -マ","*ฅ^•ﻌ•^ฅ*","₍^. .^₎⟆","ᓚᘏᗢ","ᓚ₍ ^. ༝ .^₎","₍^.  ̫.^₎","₍^. ̫.^₎","ᓚᘏᗢ ᗢᘏᓗ","/ᐠ. ｡.ᐟ\\ᵐᵉᵒʷˎˊ˗","/ᐠ. .ᐟ\\ Ⳋ","ᓚᘏᗢ ᵐᵉᵒʷ","/ᐠ. .ᐟ\\","/ᐠ - ˕ -マ Ⳋ","=^..^=","₍⑅ᐢ..ᐢ₎","૮₍ ˶ᵔ ᵕ ᵔ˶ ₎ა"],U=document.createElement("div");U.style.marginTop="50px",U.style.width="100%",U.style.backgroundColor="#ddd",U.style.borderRadius="8px",U.style.overflow="hidden",U.style.position="relative";let Y=new Map;function H(t,e,o,i="#4caf50"){let r=document.createElement("div");r.id=t;let n=document.createElement("span");n.id=t+"_text",n.style.position="absolute",n.style.width="100%",n.style.textAlign="center",n.style.alignSelf="center",n.style.justifySelf="center",n.style.fontSize="calc(0.3em + 0.55vw)",n.style.color="#000",n.style.whiteSpace="nowrap",n.style.fontFamily="schibsted-grotesk, sans-serif";let a=document.createElement("div");return a.id=t+"_bar",a.style.width="0%",a.style.height="20px",a.style.borderRadius="8px",a.style.display="flex",a.style.margin="3px 3px 3px 3px",a.style.backgroundColor=i,a.style.transition="width 0.3s ease",a.appendChild(n),U.appendChild(a),r}async function O(t="main",e,o="Progress: ",i=!1,r=20,n=5){(e<=0||e>=100||e%n||i)&&(setTimeout(V,r,t,e,o),await Promise.resolve())}async function Z(t){let e=document.getElementById(t+"_text"),o=document.getElementById(t+"_bar");o.style.display="none",e.style.display="none",e&&e.remove(),o&&o.remove()}Y.set("main",H("main",Y.size+1,"","#4caf50"));let X="";async function V(t="main",e,o="Progress: "){let i=X;(Math.floor(e)%10==0||Math.floor(e)%10==5)&&(i=G[Math.floor(Math.random()*G.length)]);let r=Y.get(t);if(r){let n=document.getElementById(t+"_text"),a=document.getElementById(t+"_bar"),s=parseFloat(a.style.marginLeft)||0,l=parseFloat(a.style.marginRight)||0;e>=0?(a.style.width=a.style.width=`calc(${e.toFixed(2)}% - ${s+l}px)`,n.textContent=o+`${e.toFixed(2)}% `+i):n.textContent=o,X=i}}let K=document.querySelector("#gsc_prf_w"),tt=document.createElement("div");function te(t=-1){let i=document.querySelectorAll(".double_range_slider_box input"),r=document.getElementById("double_range_track"),n=document.querySelector(".minvalue"),a=document.querySelector(".maxvalue"),s=t>0?t:parseInt(i[0].value),c=parseInt(i[1].value);c-s<1&&(i[0].value=c-1);let d=parseInt(i[0].value),g=parseInt(i[1].value);r.style.left=(d-e)/(o-e)*100+"%",r.style.right=100-(g-e)/(o-e)*100+"%",n.textContent=d,a.textContent=g,n.style.left=(d-e)/(o-e)*100+"%",a.style.left=(g-e)/(o-e)*100+"%",l=parseInt(i[0].value)}function to(t=-1){let i=document.querySelectorAll(".double_range_slider_box input"),r=document.getElementById("double_range_track"),n=document.querySelector(".minvalue"),a=document.querySelector(".maxvalue"),s=parseInt(i[0].value),l=t>0?t:parseInt(i[1].value);l-s<1&&(i[1].value=s+1);let d=parseInt(i[0].value),g=parseInt(i[1].value);r.style.left=(d-e)/(o-e)*100+"%",r.style.right=100-(g-e)/(o-e)*100+"%",n.textContent=d,a.textContent=g,n.style.left=(d-e)/(o-e)*100+"%",a.style.left=(g-e)/(o-e)*100+"%",c=parseInt(i[1].value)}function ti(t=-1){let i=document.getElementById("single_range_track"),r=document.getElementById("single_range"),n=document.querySelector(".singlevalue"),a=t>0?t:parseInt(r.value);i.style.right=100-(a-e)/(o-e)*100+"%",i.style.left="0%",n.textContent=a,n.style.left=(a-e)/(o-e)*100+"%",d=a}function tr(){let t=document.getElementById("cumulative_checkbox"),e=document.getElementById("single_range_track"),o=document.getElementById("peryear_checkbox");t.checked?(e.style.display="flex",s=!0):(e.style.display="none",s=!1),n=o.checked,a=t.checked}function tn(){let t=document.getElementById("cumulative_checkbox"),e=document.querySelector('label[for="cumulative_checkbox"]'),o=document.getElementById("peryear_checkbox"),i=document.getElementById("double_range_slider"),r=document.getElementById("single_range_slider");o.checked?(i.style.display="none",r.style.display="flex",t.style.display="inline-block",e.style.display="inline-block",s?(t.checked=!0,tr()):t.checked=!1):(i.style.display="flex",r.style.display="none",t.style.display="none",e.style.display="none"),n=o.checked,a=t.checked}tt.setAttribute("id","chart-viz"),tt.style.display="none",K.appendChild(tt),K.appendChild(U),!function t(){let i=document.createElement("style");i.textContent=`
            .range_slider_wrapper {
    display: flex;
    justify-content: center;  /* Center the content */
    align-items: center;
    width: 100%;
    padding: 20px;
    box-sizing: border-box;
    background-color: #f5f5f5;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);  /* Shadow effect */
    border-radius: 15px;  /* Rounded border */
}

.range_slider_container {
    width: 400px; /* Decrease the overall width of the container */
    margin: 0 auto;
    display: flex;
    justify-content: space-between;
    align-items: center;
    position: relative;
}

.toggle_container {
    margin-bottom: 5px;
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 5px;
    transform: translate(0, 20%);
}

#peryear_checkbox {
    display: inline-block;
    width: 15px; /* Adjust size as needed */
    height: 15px;
    position: relative;
    margin: 15px 0 0 0;
    padding: 0;
    pointer-events: auto;
    cursor: pointer;
    background-color: white; /* Default background */
    border: 2px solid black;
    border-radius: 4px; /* For rounded corners */
}

#peryear_checkbox:checked {
    background-color: black;
    border-color: black;
}

#peryear_checkbox:checked::after {
    content: '✓';
    color: white;
    font-size: 16px; /* Adjust size as needed */
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
}

#cumulative_checkbox {
    display: inline-block;
    width: 15px; /* Adjust size as needed */
    height: 15px;
    position: relative;
    margin: 15px 15px 0 0;
    padding: 0;
    pointer-events: auto;
    cursor: pointer;
    background-color: white; /* Default background */
    border: 2px solid black;
    border-radius: 4px; /* For rounded corners */
}

#cumulative_checkbox:checked {
    background-color: black;
    border-color: black;
}

#cumulative_checkbox:checked::after {
    content: '✓';
    color: white;
    font-size: 16px; /* Adjust size as needed */
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
}

.double_range_slider_box, .single_range_slider_box {
    position: relative;
    width: 100%; /* Adjust width */
    max-width: 250px; /* Decrease max-width */
    height: 80px; /* Decrease height */
    background: white;
    display: flex;
    justify-content: center;
    align-items: center;
    border-radius: 20px;
    overflow: visible;
}

.range_slider {
    width: 100%;
    height: 8px; /* Decrease slider height */
    position: relative;
    background-color: #dddddd;
    border-radius: 20px;
}

.range_track {
    height: 100%;
    position: absolute;
    border-radius: 20px;
    background-color: #000000; /* Light grey */
    z-index: 1;
    transition: width 0.3s ease-in-out;  /* Smooth transition */
    left: 0;  /* Ensure it starts from the left */
    top: 0;
}

.minvalue, .maxvalue, .singlevalue {
    position: absolute;
    padding: 3px 8px; /* Decrease padding */
    background: #0e5f59;
    border-radius: 1rem;
    color: white;
    font-size: 0.8rem; /* Reduce font size */
    z-index: 10;
    white-space: nowrap;
    max-width: fit-content;
}

/* Position adjustments */
.minvalue {
    left: 0;
    width: fit-content;
    transform: translate(-50%, 80%);
    transition: left 0.3s cubic-bezier(0.165, 0.84, 0.44, 1);
}

.maxvalue {
    right: 0;
    width: fit-content;
    transform: translate(-50%, -120%);
    transition: right 0.3s cubic-bezier(0.165, 0.84, 0.44, 1);
}

.singlevalue {
    width: fit-content;
    transform: translate(-50%, -120%);
    transition: right 0.3s cubic-bezier(0.165, 0.84, 0.44, 1);
}

/* General range slider input settings */
input {
    position: absolute;
    width: 100%;
    height: 5px;
    background: none;
    pointer-events: none;
    -webkit-appearance: none;
    -moz-appearance: none;
    top: 50%;
    transform: translate(-0.75%,-75%);
    z-index: 3;
}

/* Thumb style for Webkit (Chrome, Safari) */
input::-webkit-slider-thumb {
    height: 20px; /* Decrease thumb size */
    width: 20px;
    border-radius: 50%;
    border: 3px solid #696969; /* Light grey for border */
    background-color: #d3d3d3; /* Dark grey for thumb */
    pointer-events: auto;
    -webkit-appearance: none;
    cursor: pointer;
    margin-bottom: 0;
    z-index: 4;
}

/* Thumb style for Mozilla (Firefox) */
input::-moz-range-thumb {
    height: 20px; /* Decrease thumb size */
    width: 20px;
    border-radius: 50%;
    border: 3px solid #696969; /* Light grey for border */
    background-color: #d3d3d3; /* Dark grey for thumb */
    pointer-events: auto;
    -moz-appearance: none;
    cursor: pointer;
    margin-top: 0;
    z-index: 4;
}
/* CSS styles for sharma_index_container and sh_table */
.sharma_index_container {
    font-size: 1.0rem;
    font-weight: 500;
    margin-bottom: 10px;
    justify-content: center;
    display: inline-block;
}

/* .sh_table_container {
    width: 80%;
    border: black;
    border-style: solid;
    border-top-left-radius: 10px;
    border-top-right-radius: 10px;
    border-bottom-right-radius: 10px;
    border-bottom-left-radius: 10px;
    display: block;
    margin: 0 auto;
}

.sh_table_container table td, 
.sh_table_container table th {
  border: 1px solid black;
} */

  .sh_table_container-outer {
  border: 2px solid #2c3e50;
  border-radius: 12px;
  overflow: hidden;
  width: 100%;
  max-width: 600px;
  margin: 1rem 0;
  margin-left: auto;
  margin-right: auto;
}

.sh_table_container-inner {
  width: 100%;
  border-collapse: collapse;
  background: white;
}

.sh_table_container-inner th,
.sh_table_container-inner td {
  padding: 14px;
  text-align: left;
  border-bottom: 1px solid #ecf0f1;
  border-right: 1px solid #ecf0f1;
}

.sh_table_container-inner th {
  background-color: #34495e;
  color: white;
  border-right: 1px solid #2c3e50;
}

.sh_table_container-inner tr:last-child td {
  border-bottom: none;
}

.sh_table_container-inner td:last-child,
.sh_table_container-inner th:last-child {
  border-right: none;
}

/* Thanks DeepSeek R1 */
.journalTableStyle {
  border: 2px solid #333;
  border-radius: 10px;
  overflow: hidden;
  border-collapse: separate;
  border-spacing: 0px;
  /*border-collapse: collapse;*/
  width: 100%;
  max-width: 600px;
  margin: 1rem 0;
}

.journalTableStyle th,
.journalTableStyle td {
  padding: 12px;
  text-align: left;
  border: none;
}

.journalTableStyle thead {
  background-color: #f8f8f8;
}

.plotmetrics_table {
    table-layout: fixed;
    width: auto;
}

.plotmetrics_table_container {
    display: flex;
    justify-content: center;
}

.yearplot_table_container {
  width: 70%;
  height: 100%;
  position: relative;
}

#tenyearPubCountChart {
  width: 80% !important; /*ONLY CHANGE THIS to modify width of decade plot*/
  height: 100% !important;
} 

.position-circles {
    transition: all 0.2s ease-in-out;
    position: relative;
}

.circles-container {
    transition: all 0.2s ease-in-out;
    position: relative;
}

.position-circles:hover .circles-container{
    transform: scale(1.10);
    z-index: 1000;
    opacity: 1;
}

.position-circles:hover .q-badge {
    opacity: 1;
    transform: scale(1.10) ;/*translateX(50%);  Combine transforms */;
    z-index: 1000;
}

.position-circles:hover .if-badge {
    opacity: 1;
    transform: scale(1.10) ;/*translateX(55%);  Combine transforms */;
    z-index: 1000;
}

/* Optional: Add tooltip for circle meanings */
.position-circles span {
    position: relative;
    /*cursor: help;*/
}

.position-circles span[data-role]:hover::after {
    content: attr(data-role);
    position: absolute;
    bottom: 100%;
    left: 50%;
    transform: translateX(-50%); 
    background: #333;
    color: white;
    padding: 4px 8px;
    margin-bottom: 5px;
    z-index: 10;
    border-radius: 4px;
    font-size: 12px;
    white-space: nowrap;
    transform: translateX(-50%) scale(1/1.15); /* Counteract parent scale */
}

/*Stats table*/

.metrics_table_container {
    max-width: 600px;
    margin: 20px auto;
    padding: 10px;
    /*font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;*/
    font-size: 14px;
    background-color: #ffffff;
    border: 1px solid #ddd;
    border-radius: 8px;
    box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05);
    overflow-x: auto;
}

.metrics_table_container table {
    width: 100%;
    border-collapse: collapse;
}

.metrics_table_container th,
.metrics_table_container td {
    padding: 12px 15px;
    border-bottom: 1px solid #eaeaea;
    text-align: left;
    vertical-align: middle;
}

.metrics_table_container th {
    background-color: #f9f9f9;
    font-weight: 600;
    color: #333;
}

.metrics_table_container td {
    text-align: center;
    color: #444;
}

.metrics_table_container tr:nth-child(even) {
    background-color: #fcfcfc;
}

.metrics_table_container tr:hover {
    background-color: #f1f7ff;
    transition: background-color 0.2s ease-in-out;
}

            `,document.head.appendChild(i);let r=document.querySelector("#chart-viz");if(r){r.style.marginTop="50px",r.innerHTML=DOMPurify.sanitize(`
                    <div id="Core Pivotal">
                        <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
                        <div style="font-family = 'schibsted-grotesk, sans-serif'; padding: 20px; marginTop: 10px; margin: 35px; border: 1px solid #ddd; border-radius: 10px; box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.05); background-color: #fff;">
                            <div style="text-align: center;">
                                <div class="sharma_index_container">
                                    
                                    <br>
                                    
                                </div>
                            </div>
                            <br>
                            <div class="sh_table_container-outer">
                                <table class="sh_table_container-inner" /*style="width: 100%;"*/>
                                    <tr>
                                        <th style="text-align: center; padding: 8px 0;">H<sub>CP</sub> - Core Pivotal</th>
                                        
                                        <th style="text-align: center; padding: 8px 0;">Core Pivotal Citations</th>
                                        <th style="text-align: center; padding: 8px 0;">Number of Core Pivotal Papers</th>
                                        
                                        
                                        
                                        
                                        
                                    </tr>
                                    <tr>
                                        <td id="h_cp_display" style="text-align: center;">${m}</td>
                                        <td id="cp_citations" style="text-align: center;">${P[4].toFixed(0)}</td>
                                        <td id="cp_papers" style="text-align: center;">${z[4]}</td>
                                        
                                    </tr>
                                </table>
                            </div>
                        </div>
                    </div>
                    `)}}();let ts=document.createElement("button");ts.id="downloadDetailsButton",ts.disabled=!0,ts.style.fontFamily="schibsted-grotesk, sans-serif",ts.style.marginTop="10px",ts.style.marginRight="10px",ts.textContent="Download Details",K.appendChild(ts),ts.addEventListener("click",function(){let t=new Blob([tsvContent],{type:"text/tab-separated-values"}),e=URL.createObjectURL(t),o=document.createElement("a");o.href=e,o.download=`${td.replace(/\s+/g,"_")}_publications.tsv`,o.click()});let tl=document.createElement("button");tl.id="downloadPlotsButton",tl.disabled=!0,tl.style.fontFamily="schibsted-grotesk, sans-serif",tl.style.marginTop="10px",tl.style.marginRight="10px",tl.textContent="Download Plots",K.appendChild(tl),tl.addEventListener("click",function(){let t=chrome.runtime.getURL("libs/dom-to-image-more.min.js");loadScript(t,function t(){var e=document.getElementById("Core Pivotal");domtoimage.toJpeg(e).then(function(t){var e=document.createElement("a");e.download=`${td.replace(/\s+/g,"_")}_plots.jpeg`,e.href=t,e.click()}).catch(function(t){console.error("Error: Could not capture the plots!",t)})},"captureplots_script")});let tc=document.querySelector("#gsc_prf_in"),td=tc?tc.textContent.trim():"Not found";function tg(t){let e=/\b(dr|mr|mrs|ms|miss|prof|phd|ph\.?d|md|m\.?d|jr|sr)\b/gi,o=t.replace(e,"");return o=(o=(o=o.replace(/[.,\/#!$%\^&\*;:}=\_`~)]/g,"")).replace(/\s+/g," ").trim()).split(/[,\.\(\;\:\[\{\*)]/)[0].trim()}function tu(t){return t.replace("/[.*+?^${}()|[]\\]/g","\\$&")}let t$=document.querySelector("#gsc_prf_in").textContent.trim(),tp=document.querySelector("#gs_prf_ion_txt"),th="";void 0!=tp&&(th=tp.textContent.trim());let tb=[],tf=[];if(th.length>0){let ty=th.split(/;|,|:/).map(t=>t.trim()).filter(Boolean),t8=0;for(;t8<ty.length;)t8+1<ty.length&&1===ty[t8].split(" ").length?(ty[t8]=`${ty[t8]}, ${ty[t8+1]}`,ty.splice(t8+1,1)):t8++;tf=(tf=(tf=ty.filter(t=>2===t.split(" ").length)).map(t=>{let e=t.replace(/[^\w\s-]|_/g,"").replace(/\s+/g," ").trim();return e=e.replace(/[–—]/g,"-"),tg(replaceSpecialChars(normalizeString(e)))})).filter(t=>""!==t.trim());let t_=tf.map(t=>{let e=t.split(" ").map(t=>t.trim());return e.reverse().join(" ")});tf=(tf=[...tf,...t_]).map(t=>t.replace(/[^\w\s]|_/g,"").replace(/\s+/g," ").trim()),tf=Array.from(new Set(tf))}let tx=tg(replaceSpecialChars(normalizeString(t$))),tm=function t(e){let o=e.split(" "),i=o[o.length-1];return i}(tx),tC=function t(e){let o=e.split(" ");if(1===o.length)return[e];{let i=o[0].charAt(0),r=o[o.length-1],n=`${i} ${r}`,a=`${o[0]} ${o[1].charAt(0)}`,s=`${r} ${o[0]}`,l=`${r} ${i}`,c=`${r.charAt(0)} ${o[0]}`;return[n,a,s,l,c]}}(tx);tb.push(tx),tb=[...tb=[...tb,...tC],...tf],tb=Array.from(new Set(tb));let tw=[],tv=[];function tk(t,e){return M.get(e).size<=0||!M.get(e).has("author_pos_cite_qscore")?[0,0,0,0]:[M.get(e).get("author_pos_cite_qscore").get("first_author").get(t),M.get(e).get("author_pos_cite_qscore").get("second_author").get(t),M.get(e).get("author_pos_cite_qscore").get("co_author").get(t),M.get(e).get("author_pos_cite_qscore").get("corresponding_author").get(t)]}function t0(t,e){return M.get(e).size<=0||!M.get(e).has("author_pos_cite_qscore")?[0,0,0,0,0]:[M.get(e).get("author_pos_cite_qscore").get(t).get("Q1"),M.get(e).get("author_pos_cite_qscore").get(t).get("Q2"),M.get(e).get("author_pos_cite_qscore").get(t).get("Q3"),M.get(e).get("author_pos_cite_qscore").get(t).get("Q4"),M.get(e).get("author_pos_cite_qscore").get(t).get("NA"),]}function tS(t,e){return M.get(e).size<=0||!M.get(e).has("author_pos_cite_qscore")?0:M.get(e).get("author_pos_cite_qscore").get(t).get("Q1")+M.get(e).get("author_pos_cite_qscore").get(t).get("Q2")+M.get(e).get("author_pos_cite_qscore").get(t).get("Q3")+M.get(e).get("author_pos_cite_qscore").get(t).get("Q4")+M.get(e).get("author_pos_cite_qscore").get(t).get("NA")}function t3(t,e){return M.get(e).size<=0||!M.get(e).has("qPosCount")?[0,0,0,0]:[M.get(e).get("qPosCount").get("first_author").get(t),M.get(e).get("qPosCount").get("second_author").get(t),M.get(e).get("qPosCount").get("co_author").get(t),M.get(e).get("qPosCount").get("corresponding_author").get(t)]}function tA(t,e){return M.get(e).size<=0||!M.get(e).has("qPosCount")?[0,0,0,0]:[M.get(e).get("qPosCount").get("first_author").get(t)/t1("first_author",e).reduce((t,e)=>t+e,0)*100,M.get(e).get("qPosCount").get("second_author").get(t)/t1("second_author",e).reduce((t,e)=>t+e,0)*100,M.get(e).get("qPosCount").get("co_author").get(t)/t1("co_author",e).reduce((t,e)=>t+e,0)*100,M.get(e).get("qPosCount").get("corresponding_author").get(t)/t1("corresponding_author",e).reduce((t,e)=>t+e,0)*100]}function t1(t,e){return M.get(e).size<=0||!M.get(e).has("qPosCount")?[0,0,0,0,0]:[M.get(e).get("qPosCount").get(t).get("Q1"),M.get(e).get("qPosCount").get(t).get("Q2"),M.get(e).get("qPosCount").get(t).get("Q3"),M.get(e).get("qPosCount").get(t).get("Q4"),M.get(e).get("qPosCount").get(t).get("NA")]}function tq(t,e){return M.get(e).size<=0||!M.get(e).has("qPosCount")?0:M.get(e).get("qPosCount").get(t).get("Q1")+M.get(e).get("qPosCount").get(t).get("Q2")+M.get(e).get("qPosCount").get(t).get("Q3")+M.get(e).get("qPosCount").get(t).get("Q4")+M.get(e).get("qPosCount").get(t).get("NA")}function tE(t,e){return M.get(e).size<=0||!M.get(e).has("qPosCount")?[0,0,0,0,0]:[M.get(e).get("qPosCount").get(t).get("Q1")/M.get(e).get("qTotal").get("Q1")*100,M.get(e).get("qPosCount").get(t).get("Q2")/M.get(e).get("qTotal").get("Q2")*100,M.get(e).get("qPosCount").get(t).get("Q3")/M.get(e).get("qTotal").get("Q3")*100,M.get(e).get("qPosCount").get(t).get("Q4")/M.get(e).get("qTotal").get("Q4")*100,M.get(e).get("qPosCount").get(t).get("NA")/M.get(e).get("qTotal").get("NA")*100]}function t2(t){return M.get(t).size<=0||!M.get(t).has("total_publications")?0:M.get(t).get("total_publications")}function tP(t){return M.get(t).size<=0||!M.get(t).has("author_pos_contrib")?[0,0,0,0]:[M.get(t).get("author_pos_contrib").get("first_author"),M.get(t).get("author_pos_contrib").get("second_author"),M.get(t).get("author_pos_contrib").get("co_author"),M.get(t).get("author_pos_contrib").get("corresponding_author")]}function t9(t){return M.get(t).size<=0||!M.get(t).has("author_pos_cite_contrib")?[0,0,0,0]:[M.get(t).get("author_pos_cite_contrib").get("first_author"),M.get(t).get("author_pos_cite_contrib").get("second_author"),M.get(t).get("author_pos_cite_contrib").get("co_author"),M.get(t).get("author_pos_cite_contrib").get("corresponding_author")]}function tj(t){return M.get(t).size<=0||!M.get(t).has("author_pos_cite_map")?[0,0,0,0]:[M.get(t).get("author_pos_cite_map").get("first_author"),M.get(t).get("author_pos_cite_map").get("second_author"),M.get(t).get("author_pos_cite_map").get("co_author"),M.get(t).get("author_pos_cite_map").get("corresponding_author")]}function tz(t,e,o){let i=[0,0,0,0];for(let r=e;r<=o;r++){if(!J.includes(r.toString()))continue;let n=tk(t,r.toString());for(let a=0;a<4;a++)i[a]+=n[a]}return i}function tQ(t,e,o){let i=[0,0,0,0,0];for(let r=e;r<=o;r++){if(!J.includes(r.toString()))continue;let n=t0(t,r.toString());for(let a=0;a<5;a++)i[a]+=n[a]}return i}function tI(t,e,o){let i=0;for(let r=e;r<=o;r++)J.includes(r.toString())&&(i+=tS(t,r.toString()));return i}function t6(t,e,o){let i=[0,0,0,0];for(let r=e;r<=o;r++){if(!J.includes(r.toString()))continue;let n=t3(t,r.toString());for(let a=0;a<4;a++)i[a]+=n[a]}return i}function tB(t,e,o){let i=[0,0,0,0];for(let r=e;r<=o;r++){if(!J.includes(r.toString()))continue;let n=tA(t,r.toString());for(let a=0;a<4;a++)i[a]+=n[a]}let s=Math.abs(o-e);for(let l=0;l<4;l++)i[l]=i[l]/s*100;return i}function tR(t,e,o){let i=[0,0,0,0,0];for(let r=e;r<=o;r++){if(!J.includes(r.toString()))continue;let n=t1(t,r.toString());for(let a=0;a<5;a++)i[a]+=n[a]}return i}function tT(t,e,o){let i=0;for(let r=e;r<=o;r++)J.includes(r.toString())&&(i+=tq(t,r.toString()));return i}function t4(t,e,o){let i=[0,0,0,0,0];for(let r=e;r<=o;r++){if(!J.includes(r.toString()))continue;let n=tE(t,r.toString());for(let a=0;a<5;a++)i[a]+=n[a]}let s=Math.abs(o-e);for(let l=0;l<5;l++)i[l]=i[l]/s*100;return i}function tL(t,e){let o=0;for(let i=t;i<=e;i++)J.includes(i.toString())&&(o+=t2(i.toString()));return o}function tN(){}function tD(){}async function tW(){}tb.forEach(t=>{tw.push(function t(e){let o=e.trim().split(/\s+/),i=tu(o[o.length-1]),r=tu(o[0].charAt(0));return o[0].length>1&&i.length>1?RegExp(`^${r}.*\\s${i}[\\*^]?$`,"i"):RegExp(`^${o[0]}.*\\s${i}[\\*^]?$`,"i")}(t)),tv.push(function t(e){let o=e.trim().split(/\s+/),i=tu(o[0]),r=tu(o[o.length-1]);return RegExp(`^${i}.*\\s${r}[\\*^]?$`,"i")}(t))});let t5=async()=>{document.getElementsByTagName("body")[0].style.overflow="visible";let t=document.querySelectorAll(".gsc_a_tr"),n=new Map;t.forEach(async(t,i)=>{let r=t.querySelector(".gsc_a_t a"),a=r?r.textContent.trim():"No title",s=r?r.href:null,g=t.querySelector(".gsc_a_c a"),u=g?g.textContent.trim():"0",$=parseInt(u,0);isNaN($)&&($=0);let p=t.querySelectorAll(".gsc_a_t .gs_gray"),h=t.querySelector(".gs_oph"),b=h&&h.previousSibling?h.previousSibling.textContent.trim():"Unknown Journal";if(null!=b.toLowerCase().match(/rxiv/))A++;else{let f=b.match(I),y=f?f[1].trim():b;Q.has(y)||Q.set(y,0),Q.set(y,Q.get(y)+1)}let _=t.querySelector(".gsc_a_y span"),x=_?_.textContent.trim():"No year";t.year="No year"!=x||void 0!=x?parseInt(x):0;let m=t.querySelector(".gs_ibl");m&&m.hasAttribute("href")&&m.getAttribute("href"),(parseInt(x)<e||0===e)&&(l=e=parseInt(x)),parseInt(x)>o&&(c=o=parseInt(x),d=o),"No year"==x||void 0==x||(M.has(x)||M.set(x,new Map),J.includes(x)||J.push(x));let C=p[0],w=C?C.textContent.trim():"No authors",v=function t(e,o,i=[5,7]){let r=e.toLowerCase().split(/,\s*(.+)/)[0].replace(/\d+/g,"").replace(/[^\w\s]|_/g,"").replace(/\s+/g," ").trim();if(n.has(r))return n.get(r);for(let a of o)if(a.Name&&r.includes(a.Name.toLowerCase())&&a.Name.toLowerCase().includes(r)){let s=Array.from(Object.values(a));if(!(s.length>=Math.max(...i)))return n.set(r,["NA","NA"]),["NA","NA"];{let l=[a.JIF5Years,a.Qscore];return n.set(r,l),l}}return n.set(r,["NA","NA"]),["NA","NA"]}(b,excelData,[5,7]);D.push({title:a,citations:$,year:x,authors:w,total_authors:0,author_pos:"NA",journalRanking:v[1],journalTitle:b,impact_factor:v[0],index:i,publicationURL:s})});let a=[...Q.entries()].sort((t,e)=>e[1]-t[1]).slice(0,3),s=`
            <table class="journalTableStyle">
                <thead>
                <tr>
                    <th>Journal Name</th>
                    <th>Count</th>
                </tr>
                </thead>
                <tbody>
                ${a.map(([t,e])=>`
                    <tr>
                    <td>${t}</td>
                    <td>${e}</td>
                    </tr>
                `).join("")}
                </tbody>
            </table>
            `;let journalTableEl=document.getElementById("journalTable");if(journalTableEl){journalTableEl.innerHTML=DOMPurify.sanitize(s)}let b=document.querySelectorAll(".double_range_slider_box input"),f=document.getElementById("single_range");async function y(t,e,o=5,i=0){let r=[];try{let n=0;e.length>=100&&(i=i>1e4?i:1e4);let a=async()=>{if(n>=e.length)return;let s=e.slice(n,n+o);n+=o,await new Promise(t=>setTimeout(t,i));let l=s.map(async(e,o)=>{try{let i,r=new DOMParser;try{i=await fetchWithSessionCache(t[o],e);let n=0;for(;!i||200!=i.status;){if(i=await fetchWithSessionCache(t[o],e,refetch=!0),++n>5)throw Error("Request limit exceeded. Refresh the page and rerun Core Pivotal.");await new Promise(t=>setTimeout(t,0))}let a=await i.text(),s=r.parseFromString(DOMPurify.sanitize(a),"text/html"),l=s.querySelector(".gsc_oci_value");return await new Promise(t=>setTimeout(t,0)),l?l.textContent.trim():"Authors not found"}catch(c){console.error("Error fetching authors:",c),chrome.runtime.sendMessage({type:"release_semaphore"},t=>{console.log(t.status),window.alert("Large Profile : Rate limit reached. Please re-run Core Pivotal."),window.location.reload()})}return"Authors not found"}catch(d){return console.error("Error fetching authors (batch.map):",d),"Error loading authors"}});r.push(...await Promise.all(l)),O("main",n/e.length*100,"Fetching URLs("+n+"): "),await new Promise(t=>setTimeout(t,0)),await a()};await a(),await new Promise(t=>setTimeout(t,0))}catch(s){console.log("Error Fetching Authors:",s),await releaseSemaphoreAndReload()}return r}function _(t,e){let o=e;for(;o>0&&(t[o].includes("^")||t[o].includes("*"));)o--;return o}if(f){f.min=e,f.max=o,f.value=d.toString()}if(b&&b.length>=2){b[0].min=e,b[0].max=o,b[0].value=l.toString(),b[1].min=e,b[1].max=o,b[1].value=c.toString()}async function x(){let t=!1,e=new Set;new TextEncoder;let o=[];Y.set("publication_progress",H("publication_progress",Y.size+1,"Processing Publications...","rgb(103, 0, 172)")),O("publication_progress",-1,"Processing Publications...");for(let n=0;n<i/2;n++){let a=await createInlineWorker(chrome.runtime.getURL("workers/publicationWorker.min.js"));a.idle=!0,o.push(a)}for(let s=0;s<D.length;s+=r){let l=D.slice(s,s+r).filter(t=>!W.includes(t.index)),c=l.map(t=>t.index);for(;c.some(t=>t>g);)await new Promise(t=>setTimeout(t,50));for(;!o.find(t=>t.idle);)await new Promise(t=>setTimeout(t,100));let d=o.find(t=>t.idle);d.idle=!1,d.onmessage=async({data:o})=>{let i=new TextDecoder("utf-8"),r=i.decode(new Uint8Array(o)),n=JSON.parse(r);if("initialScrape"===n.task&&"working"===n.type){if(D[n.publication.index]=n.publication,n.publication.authors.includes("...")||!D[n.publication.index].authorFound&&D[n.publication.index].extended_scrape){t=!0,D[n.publication.index].extended_scrape=!0;return}let authorsList=n.publication.authors.split(/[,;]/).map(a=>a.trim());let actualAuthorCount=authorsList.length;if(actualAuthorCount>0&&actualAuthorCount%2===1){let middlePos=Math.floor(actualAuthorCount/2)+1;if(authorsList.length>=middlePos){let middleAuthor=authorsList[middlePos-1];let middleAuthorLower=middleAuthor.toLowerCase();let isMiddleTarget=false;for(let regex of tw)if(regex.test(middleAuthor)){isMiddleTarget=true;break}if(!isMiddleTarget&&middleAuthorLower.includes(tm.toLowerCase()))isMiddleTarget=true;if(!isMiddleTarget&&tf.includes(middleAuthor.trim()))isMiddleTarget=true;if(!isMiddleTarget&&tC.includes(middleAuthor.trim()))isMiddleTarget=true;if(isMiddleTarget)n.publication.author_pos="core_pivotal_author"}}switch(n.publication.author_pos){case"first_author":D[n.publication.index].author_pos_string="1	0	0	0	0",D[n.publication.index].adjustedCitationCount=n.publication.citations*E[0],P[0]+=D[n.publication.index].adjustedCitationCount,D[n.publication.index].citationWeight=E[0];break;case"second_author":D[n.publication.index].author_pos_string="0	1	0	0	0",D[n.publication.index].adjustedCitationCount=n.publication.citations*E[1],P[1]+=D[n.publication.index].adjustedCitationCount,D[n.publication.index].citationWeight=E[1];break;case"co_author":D[n.publication.index].author_pos_string="0	0	1	0	0",n.publication.total_authors>6?(D[n.publication.index].adjustedCitationCount=.1*n.publication.citations,D[n.publication.index].citationWeight=.1):(D[n.publication.index].adjustedCitationCount=.25*n.publication.citations,D[n.publication.index].citationWeight=.25),P[2]+=D[n.publication.index].adjustedCitationCount;break;case"corresponding_author":D[n.publication.index].author_pos_string="0	0	0	1	0",D[n.publication.index].adjustedCitationCount=n.publication.citations*E[3],D[n.publication.index].citationWeight=E[3],P[3]+=D[n.publication.index].adjustedCitationCount;break;case"core_pivotal_author":D[n.publication.index].author_pos_string="0	0	0	0	1",D[n.publication.index].adjustedCitationCount=n.publication.citations*E[4],D[n.publication.index].citationWeight=E[4],P[4]+=D[n.publication.index].adjustedCitationCount;break;default:t=!0,D[n.publication.index].extended_scrape=!0,D[n.publication.index].authorFound=!1}D[n.publication.index].extended_scrape=!1,tsvContent+=`${n.publication.index}	${n.publication.title}	${n.publication.authors}	${n.publication.authors.includes("...")?`${n.publication.total_authors-1}+`:n.publication.total_authors}	${n.publication.year}	${n.publication.citations}	${n.publication.journalTitle}	${n.publication.journalRanking}	${n.publication.impact_factor}	${n.publication.considered}	${n.publication.author_pos==="core_pivotal_author"?1:0}
`,u+=1,O("publication_progress",u/$*100,"Processing Publications ("+u+"): "),await new Promise(t=>setTimeout(t,150)),e.add(n.publication.index),0===n.publication.year.toString().trim().length&&(h+=1),M.get(n.publication.year).has("total_publications")||M.get(n.publication.year).set("total_publications",0),M.get(n.publication.year).set("total_publications",M.get(n.publication.year).get("total_publications")+1)}if("done"===n.type){F=[...F,...n.authorNamesConsidered],F=Array(...new Set(F));let a=rebuildYearwiseData(n.yearwiseData);n.yearwiseData.length>0&&a.size>0&&await mergeYearwiseData(M,a),d.idle=!0,d.onmessage=null}"error"===n.type&&console.error(`Worker error on ${n.task}:`,n.error)},d.postMessage({task:"initialScrape",batch:l,authorRegexes:tw,authorRegexesEx:tv,nameComboList:tC,otherNamesList:tf,authorNameShort:tm,authorName:td,authorNameLong:tx})}if(t){for(;o.some(t=>!t.idle);)await new Promise(t=>setTimeout(t,100));let b=D.filter(t=>!0===t.extended_scrape).map(t=>t.publicationURL),f=D.filter(t=>!0===t.extended_scrape).map(t=>t.title),_=await y(f,b,b.length,0);(b=[]).length=0,(f=[]).length=0;let x=0;D.forEach(async(t,e)=>{t.extended_scrape&&(t.authors=_[x]||"Authors not found",x++)});for(let m=0;m<D.length;m+=r){let C=D.slice(m,m+r).filter(t=>!W.includes(t.index)).filter(t=>!e.has(t.index)),w=C.map(t=>t.index);for(;w.some(t=>t>g);)await new Promise(t=>setTimeout(t,50));for(;!o.find(t=>t.idle);)await new Promise(t=>setTimeout(t,100));let v=o.find(t=>t.idle);v.idle=!1,v.onmessage=async({data:t})=>{let e=new TextDecoder("utf-8"),o=e.decode(new Uint8Array(t)),i=JSON.parse(o);if("extendedScrape"===i.task&&"working"===i.type){let authorsListExt=i.publication.authors.split(/[,;]/).map(a=>a.trim());let actualAuthorCountExt=authorsListExt.length;if(actualAuthorCountExt>0&&actualAuthorCountExt%2===1){let middlePosExt=Math.floor(actualAuthorCountExt/2)+1;if(authorsListExt.length>=middlePosExt){let middleAuthorExt=authorsListExt[middlePosExt-1];let middleAuthorExtLower=middleAuthorExt.toLowerCase();let isMiddleTargetExt=false;for(let regex of tw)if(regex.test(middleAuthorExt)){isMiddleTargetExt=true;break}if(!isMiddleTargetExt&&middleAuthorExtLower.includes(tm.toLowerCase()))isMiddleTargetExt=true;if(!isMiddleTargetExt&&tf.includes(middleAuthorExt.trim()))isMiddleTargetExt=true;if(!isMiddleTargetExt&&tC.includes(middleAuthorExt.trim()))isMiddleTargetExt=true;if(isMiddleTargetExt)i.publication.author_pos="core_pivotal_author"}}D[i.publication.index].authors=i.publication.authors;D[i.publication.index].total_authors=i.publication.total_authors;D[i.publication.index].author_pos=i.publication.author_pos;D[i.publication.index].authorFound=i.authorFound;if(!i.authorFound)p+=1;u+=1;O("publication_progress",u/$*100,"Processing Publications ("+u+"): ");await new Promise(t=>setTimeout(t,150));if(0===D[i.publication.index].year.toString().trim().length)h+=1;M.get(D[i.publication.index].year).has("total_publications")||M.get(D[i.publication.index].year).set("total_publications",0);M.get(D[i.publication.index].year).set("total_publications",M.get(D[i.publication.index].year).get("total_publications")+1);switch(D[i.publication.index].author_pos){case"first_author":D[i.publication.index].author_pos_string="1	0	0	0	0",D[i.publication.index].adjustedCitationCount=D[i.publication.index].citations*E[0],P[0]+=D[i.publication.index].adjustedCitationCount,D[i.publication.index].citationWeight=E[0];break;case"second_author":D[i.publication.index].author_pos_string="0	1	0	0	0",D[i.publication.index].adjustedCitationCount=D[i.publication.index].citations*E[1],P[1]+=D[i.publication.index].adjustedCitationCount,D[i.publication.index].citationWeight=E[1];break;case"co_author":D[i.publication.index].author_pos_string="0	0	1	0	0",D[i.publication.index].total_authors>6?(D[i.publication.index].adjustedCitationCount=.1*D[i.publication.index].citations,D[i.publication.index].citationWeight=.1):(D[i.publication.index].adjustedCitationCount=.25*D[i.publication.index].citations,D[i.publication.index].citationWeight=.25),P[2]+=D[i.publication.index].adjustedCitationCount;break;case"corresponding_author":D[i.publication.index].author_pos_string="0	0	0	1	0",D[i.publication.index].adjustedCitationCount=D[i.publication.index].citations*E[3],P[3]+=D[i.publication.index].adjustedCitationCount,D[i.publication.index].citationWeight=E[3];break;case"core_pivotal_author":D[i.publication.index].author_pos_string="0	0	0	0	1",D[i.publication.index].adjustedCitationCount=D[i.publication.index].citations*E[4],P[4]+=D[i.publication.index].adjustedCitationCount,D[i.publication.index].citationWeight=E[4];break;default:D[i.publication.index].adjustedCitationCount=0,D[i.publication.index].citationWeight=0}tsvContent+=`${i.publication.index}	${i.publication.title}	${i.publication.authors}	${i.publication.authors.includes("...")?`${i.publication.total_authors-1}+`:i.publication.total_authors}	${i.publication.year}	${i.publication.citations}	${i.publication.journalTitle}	${i.publication.journalRanking}	${i.publication.impact_factor}	${i.publication.considered}	${D[i.publication.index].author_pos==="core_pivotal_author"?1:0}
`}if("done"===i.type){F=[...F,...i.authorNamesConsidered],F=Array(...new Set(F));let r=rebuildYearwiseData(i.yearwiseData);i.yearwiseData.length>0&&r.size>0&&await mergeYearwiseData(M,r),v.idle=!0,v.onmessage=null}"error"===i.type&&console.error(`Worker error on ${i.task}:`,i.error)},v.postMessage({task:"extendedScrape",batch:C,authorRegexes:tw,authorRegexesEx:tv,nameComboList:tC,otherNamesList:tf,authorNameShort:tm,authorName:td,authorNameLong:tx})}}for(;o.some(t=>!t.idle);)await new Promise(t=>setTimeout(t,100));return o.forEach(t=>t.terminate()),O("publication_progress",100,"Processing Publications :",!0),F=[...F,...tb],F=Array(...new Set(F)),Y.set("journal_progress",H("journal_progress",Y.size+1,"Processing Journal Rankings...","rgb(0, 97, 207)")),O("journal_progress",-1,"Processing Journal Rankings..."),u=0,D.forEach(async(t,e)=>{D[e].journalRanking||(D[e].journalRanking="NA"),D[e].impact_factor||(D[e].impact_factor="NA"),function t(e,o,i){if("NA"!==e){if(M.get(o).has("qPosCount")||(M.get(o).set("qPosCount",new Map),M.get(o).get("qPosCount").set("first_author",new Map),M.get(o).get("qPosCount").get("first_author").set("Q1",0),M.get(o).get("qPosCount").get("first_author").set("Q2",0),M.get(o).get("qPosCount").get("first_author").set("Q3",0),M.get(o).get("qPosCount").get("first_author").set("Q4",0),M.get(o).get("qPosCount").get("first_author").set("NA",0),M.get(o).get("qPosCount").set("second_author",new Map),M.get(o).get("qPosCount").get("second_author").set("Q1",0),M.get(o).get("qPosCount").get("second_author").set("Q2",0),M.get(o).get("qPosCount").get("second_author").set("Q3",0),M.get(o).get("qPosCount").get("second_author").set("Q4",0),M.get(o).get("qPosCount").get("second_author").set("NA",0),M.get(o).get("qPosCount").set("co_author",new Map),M.get(o).get("qPosCount").get("co_author").set("Q1",0),M.get(o).get("qPosCount").get("co_author").set("Q2",0),M.get(o).get("qPosCount").get("co_author").set("Q3",0),M.get(o).get("qPosCount").get("co_author").set("Q4",0),M.get(o).get("qPosCount").get("co_author").set("NA",0),M.get(o).get("qPosCount").set("corresponding_author",new Map),M.get(o).get("qPosCount").get("corresponding_author").set("Q1",0),M.get(o).get("qPosCount").get("corresponding_author").set("Q2",0),M.get(o).get("qPosCount").get("corresponding_author").set("Q3",0),M.get(o).get("qPosCount").get("corresponding_author").set("Q4",0),M.get(o).get("qPosCount").get("corresponding_author").set("NA",0)),M.get(o).has("qTotal")||(M.get(o).set("qTotal",new Map),M.get(o).get("qTotal").set("Q1",0),M.get(o).get("qTotal").set("Q2",0),M.get(o).get("qTotal").set("Q3",0),M.get(o).get("qTotal").set("Q4",0),M.get(o).get("qTotal").set("NA",0)),"Q"===i.charAt(0))switch(i.charAt(1)){case"1":let r=M.get(o).get("qPosCount").get(e).get("Q1")+1;M.get(o).get("qPosCount").get(e).set("Q1",r);let n=M.get(o).get("qTotal").get("Q1")+1;M.get(o).get("qTotal").set("Q1",n);break;case"2":let a=M.get(o).get("qPosCount").get(e).get("Q2")+1;M.get(o).get("qPosCount").get(e).set("Q2",a);let s=M.get(o).get("qTotal").get("Q2")+1;M.get(o).get("qTotal").set("Q2",s);break;case"3":let l=M.get(o).get("qPosCount").get(e).get("Q3")+1;M.get(o).get("qPosCount").get(e).set("Q3",l);let c=M.get(o).get("qTotal").get("Q3")+1;M.get(o).get("qTotal").set("Q3",c);break;case"4":let d=M.get(o).get("qPosCount").get(e).get("Q4")+1;M.get(o).get("qPosCount").get(e).set("Q4",d);let g=M.get(o).get("qTotal").get("Q4")+1;M.get(o).get("qTotal").set("Q4",g)}else{let u=M.get(o).get("qPosCount").get(e).get("NA")+1;M.get(o).get("qPosCount").get(e).set("NA",u);let $=M.get(o).get("qTotal").get("NA")+1;M.get(o).get("qTotal").set("NA",$)}}}(D[e].author_pos,D[e].year,D[e].journalRanking),u+=1,O("journal_progress",u/$*100,"Processing Journal Rankings ("+u+"): "),await new Promise(t=>setTimeout(t,0))}),O("journal_progress",100,"Processing Journal Rankings :",!0),!0}async function m(){Y.set("retract_progress",H("retract_progress",Y.size+1,"Processing Retractions...","rgb(255, 251, 0)")),O("retract_progress",-1,"Processing Retractions..."),await new Promise(t=>setTimeout(t,150)),retractionWatchDB=await getRetractionWatchDB();let t=[];for(let e=0;e<i/2;e++){let o=await createInlineWorker(chrome.runtime.getURL("workers/retractionWorker.min.js"));o.idle=!0,t.push(o)}for(let n=0;n<D.length;n+=r){let a=D.slice(n,n+r);for(;!t.find(t=>t.idle);)await new Promise(t=>setTimeout(t,100));let s=t.find(t=>t.idle);s.idle=!1,s.onmessage=async({data:t})=>{let e=new TextDecoder("utf-8"),o=e.decode(new Uint8Array(t)),i=JSON.parse(o);"checkRetraction"===i.task&&"working"===i.type&&(g+=1,O("retract_progress",g/$*100,"Processing Retractions ("+g+"): "),await new Promise(t=>setTimeout(t,150)),i.publication.retracted?(D[i.publication.index].retracted=!0,W.push(i.publication.index),S++):D[i.publication.index].retracted=!1),"done"===i.type&&(s.idle=!0,s.onmessage=null),"error"===i.type&&console.error(`Worker error on ${i.task}:`,i.error)},s.postMessage({task:"checkRetraction",batch:a,retractionWatchDB})}for(;t.some(t=>!t.idle);)await new Promise(t=>setTimeout(t,100));return t.forEach(t=>t.terminate()),O("retract_progress",100,"Processing Retractions : "),!0}O("main",-1,"Please Wait...",!0);let[C,w]=await Promise.all([x(),m()]);function v(t,e){for(let[o,i]of e.entries())if(i instanceof Map)t.has(o)||t.set(o,new Map),v(t.get(o),i);else if(Array.isArray(i)){let r=t.get(o)||[];t.set(o,[...r,...i])}else"number"==typeof i?t.set(o,(t.get(o)||0)+i):t.set(o,i)}D.sort((t,e)=>t.index-e.index),t.forEach(async(t,e)=>{let o=D[e].author_pos;t.author_pos=o;let i=t.querySelector(".gs_gray");if(i){var r,n;let a="#ddd";if(!W.includes(e))switch(o){case"first_author":a="#3b8888";break;case"second_author":a="#5d33b8";break;case"co_author":a="#e68a41";break;case"corresponding_author":a="#3a83b2";break;default:a="#ddd"}let s=DOMPurify.sanitize(`
                        <div class="position-circles" style="display: flex; gap: 5px; margin-top: 2px; margin-left: 2px; align-items: center; position: relative;">
                            <div class="circles-container" style="display: flex; gap: 5px; margin-right: 0.30%; margin-left: 0.15%;">
        <span 
            style="width: 10px; height: 10px; border-radius: 50%; background-color: ${"first_author"===o?a:"#ddd"};"
            ${"first_author"===o?'data-role="First Author"':""}
        ></span>
        <span 
            style="width: 10px; height: 10px; border-radius: 50%; background-color: ${"second_author"===o?a:"#ddd"};"
            ${"second_author"===o?'data-role="Second Author"':""}
        ></span>
        <span 
            style="width: 10px; height: 10px; border-radius: 50%; background-color: ${"co_author"===o?a:"#ddd"};"
            ${"co_author"===o?'data-role="Co-Author"':""}
        ></span>
        <span 
            style="width: 10px; height: 10px; border-radius: 50%; background-color: ${"corresponding_author"===o?a:"#ddd"};"
            ${"corresponding_author"===o?'data-role="Corresponding Author"':""}
        ></span>
                            </div>
                            <div class="q-badge" style="
                                /*opacity: 0;*/
                                transition: all 0.2s ease-in-out;
                                background: ${{Q1:"#2e7d32",Q2:"#689f38",Q3:"#f9a825",Q4:"#ef6c00"}[r=D[e].journalRanking]||"#607d8b"};
                                color: white;
                                padding: 2px 8px;
                                border-radius: 12px;
                                font-size: 0.8em;
                                margin-right: 0.25%;
                                margin-left: 0.25%;
                                /*position: absolute;
                                left: 100%;*/
                                white-space: nowrap;
                                pointer-events: none;
                            ">
                                ${D[e].journalRanking}
                            </div>
                            <div class="if-badge" style="
                                /*opacity: 0;*/
                                transition: all 0.2s ease-in-out;
                                background: ${{Q1:"#2e7d32",Q2:"#689f38",Q3:"#f9a825",Q4:"#ef6c00"}[n=D[e].impact_factor]||"#607d8b"};
                                color: white;
                                padding: 2px 8px;
                                border-radius: 12px;
                                font-size: 0.8em;
                                margin-right: 0.25%;
                                margin-left: 0.25%;
                                /*position: absolute;
                                left: 100%;*/
                                white-space: nowrap;
                                pointer-events: none;
                            ">
                                IF5: ${D[e].impact_factor}
                            </div>
                        </div>
                    `),l=t.querySelector(".position-circles");l?l.outerHTML=s:i.insertAdjacentHTML("afterend",s)}await new Promise(t=>setTimeout(t,0))}),await new Promise(t=>setTimeout(t,0)),t.forEach(async(t,e)=>{if(!W.includes(e)){t.retracted=!1;return}t.retracted=!0;let o=t.querySelector(".gs_gray"),i=DOMPurify.sanitize(`
                <div class="blink_text"><div class="retraction-notice" style="margin-top: 5px; color: #ff0000; font-weight: bold;">
                RETRACTED</div></div>
            `);o.insertAdjacentHTML("afterend",i),await new Promise(t=>setTimeout(t,0))});M.get("")&&M.delete(""),profileScraped=!0,(async()=>{await releaseSemaphore()})()};async function t7(){Y.forEach((t,e)=>{Z(e)}),Y.clear(),tt.style.display="block";let ts=document.getElementById("downloadDetailsButton"),tl=document.getElementById("downloadPlotsButton");if(ts)ts.disabled=!1;if(tl)tl.disabled=!1}async function tF(){for(;!profileScraped;)await new Promise(t=>setTimeout(t,100));let t=[],e=[];m=D.length,D.sort((t,e)=>parseFloat(e.adjustedCitationCount)-parseFloat(t.adjustedCitationCount));let o=["first_author","second_author","co_author","corresponding_author","core_pivotal_author"];D.forEach(i=>{if(i.retracted)return;let r=i.author_pos?.toLowerCase(),n=q.findIndex(t=>t.toLowerCase()===r);if(n>=0&&o.includes(r)){z[n]++;let a=parseFloat(i.adjustedCitationCount||0);t.push(a);let s=parseFloat(i.citations||0);e.push(s),a>=z[n]&&j[n]++}});let corePivotalPapers=D.filter(i=>!i.retracted&&i.author_pos?.toLowerCase()==="core_pivotal_author").map(i=>parseFloat(i.citations||0)).sort((a,b)=>b-a);for(let h=0;h<corePivotalPapers.length;h++){if(corePivotalPapers[h]<h+1){j[4]=h;break}else if(h===corePivotalPapers.length-1){j[4]=corePivotalPapers.length}}if(corePivotalPapers.length===0)j[4]=0;let firstAuthorPapers=D.filter(i=>!i.retracted&&i.author_pos?.toLowerCase()==="first_author").map(i=>parseFloat(i.citations||0)).sort((a,b)=>b-a);for(let h=0;h<firstAuthorPapers.length;h++){if(firstAuthorPapers[h]<h+1){j[0]=h;break}else if(h===firstAuthorPapers.length-1){j[0]=firstAuthorPapers.length}}if(firstAuthorPapers.length===0)j[0]=0;let secondAuthorPapers=D.filter(i=>!i.retracted&&i.author_pos?.toLowerCase()==="second_author").map(i=>parseFloat(i.citations||0)).sort((a,b)=>b-a);for(let h=0;h<secondAuthorPapers.length;h++){if(secondAuthorPapers[h]<h+1){j[1]=h;break}else if(h===secondAuthorPapers.length-1){j[1]=secondAuthorPapers.length}}if(secondAuthorPapers.length===0)j[1]=0;let coAuthorPapers=D.filter(i=>!i.retracted&&i.author_pos?.toLowerCase()==="co_author").map(i=>parseFloat(i.citations||0)).sort((a,b)=>b-a);for(let h=0;h<coAuthorPapers.length;h++){if(coAuthorPapers[h]<h+1){j[2]=h;break}else if(h===coAuthorPapers.length-1){j[2]=coAuthorPapers.length}}if(coAuthorPapers.length===0)j[2]=0;let correspondingAuthorPapers=D.filter(i=>!i.retracted&&i.author_pos?.toLowerCase()==="corresponding_author").map(i=>parseFloat(i.citations||0)).sort((a,b)=>b-a);for(let h=0;h<correspondingAuthorPapers.length;h++){if(correspondingAuthorPapers[h]<h+1){j[3]=h;break}else if(h===correspondingAuthorPapers.length-1){j[3]=correspondingAuthorPapers.length}}if(correspondingAuthorPapers.length===0)j[3]=0;b=j[0],f=j[1],y=j[2],_=j[3],m=j[4],t.sort((t,e)=>parseFloat(e)-parseFloat(t)),e.sort((t,e)=>parseInt(e)-parseInt(t)),t.forEach((t,e)=>{t>=e+1&&(x=e+1)}),k=D.filter(t=>t.citations<=0&&!t.retracted).length,v=t[Math.floor(t.length/2)],w=D[Math.floor(D.length/2)].citations,P=[0,0,0,0,0],D.forEach(i=>{if(!i.retracted&&i.citations!==undefined){let r=i.author_pos?.toLowerCase(),n=parseFloat(i.citations||0),a=0;r==="first_author"?a=n*E[0]:r==="second_author"?a=n*E[1]:r==="co_author"?a=n*E[2]:r==="corresponding_author"?a=n*E[3]:r==="core_pivotal_author"&&(a=n*E[4]),r==="first_author"?P[0]+=a:r==="second_author"?P[1]+=a:r==="co_author"?P[2]+=a:r==="corresponding_author"?P[3]+=a:r==="core_pivotal_author"&&(P[4]+=a)}}),C=P[0]+P[1]+P[2]+P[3]+P[4],document.getElementById("h_cp_display").textContent=DOMPurify.sanitize(`${m.toString()}`),document.getElementById("cp_citations").textContent=DOMPurify.sanitize(`${P[4].toFixed(0)}`),document.getElementById("cp_papers").textContent=DOMPurify.sanitize(`${z[4].toString()}`)}let tM=async()=>{let e=document.querySelector("#gsc_bpf_more");if(await new Promise(t=>setTimeout(t,1e3)),!e)return await new Promise(t=>setTimeout(t,2e3)),tM();if(!e.hasAttribute("disabled"))return e.click(),await new Promise(t=>setTimeout(t,1500)),tM();{$=document.querySelectorAll(".gsc_a_at").length;let o=parseInt(document.querySelector("#gsc_a_nn").textContent.split(/[-–]/)[1].trim());if($>o)return await new Promise(t=>setTimeout(t,2e3)),tM();{await t5(),tF(),t7();let i=performance.now(),r=i-t,n=Math.floor(r/36e5),a=Math.floor(r%36e5/6e4),s=(r%6e4/1e3).toFixed(2),l=[];n>0&&l.push(`${n}h`),a>0&&l.push(`${a}m`),l.push(`${s}s`),console.info(`Time taken by Core Pivotal: ${l.join(" ")}`)}}};O("main",-1,"Waiting for other Core Pivotal processes to complete...",!0),chrome.runtime.sendMessage({type:"get_semaphore"},t=>{try{t&&console.log(t?.status),O("main",-1,"Expanding Publications List...",!0);let e=window.location.href.toString();fetch(e).then(t=>{200!=t.status&&(async()=>{await releaseSemaphoreAndReload()})()}),async function(){excelData=await getJCRExcel(),retractionWatchDB=await getRetractionWatchDB()}(),tM()}catch(o){console.error("Error scraping profile:",o),document.getElementsByTagName("body")[0].style.overflow="visible",(async()=>{await releaseSemaphore()})()}})}catch(tJ){console.error("Error scraping:",tJ),document.getElementsByTagName("body")[0].style.overflow="visible",(async()=>{await releaseSemaphore()})()}return!0}